# Sahayak Product Design Pack

A corporate navy-and-teal concept pack for Sahayak, an offline governance assistant focused on comparing scheme/sanction and payment spreadsheets.

## Contents
- `Sahayak_Product_Design_Pack.pdf` — 9-page landscape visual pack.
- `svg/` — editable SVG vector sources for every page (1600 x 900).
- `png/` — 1600 x 900 PNG exports for easy insertion into a report or slide deck.

## Pages
1. Cover and product scope overview
2. Low-fidelity wireframes
3. High-fidelity dashboard, upload and column-mapping concepts
4. High-fidelity results and exception-review concepts
5. Report-generation concept and sample output
6. End-to-end workflow
7. Local desktop system architecture
8. Matching and exception logic
9. Synthetic sample reconciliation report

## Important design boundaries
- These are proposed design concepts, not claims that the UI or any feature has already been implemented.
- All names, IDs and amounts in the sample report are fictional.
- The optional local AI component is shown only as a possible aid for suggesting unfamiliar column names; core matching and financial calculations are intended to be deterministic.
- Uncertain/fuzzy matches require human review. A difference in amount is reported separately from identity matching.
- Multiple payment lines for one entitlement are not shown as silently excluded; they should be flagged for review because V0 assumes one-to-one rows.
- No live government API, payment approval, Aadhaar processing or document OCR is depicted as available.

## Editing
Open the relevant `.svg` file in Figma, Inkscape, Illustrator, or another SVG-capable editor. Text and shapes are vector objects; fonts may substitute depending on the editor.
